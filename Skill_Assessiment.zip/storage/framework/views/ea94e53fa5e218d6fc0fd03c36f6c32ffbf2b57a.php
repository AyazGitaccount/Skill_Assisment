<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->id); ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->vists); ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->add_url); ?></td>
                                       



<td class="px-6 py-4 text-right text-sm">
  <button class="px-6 py-2.5 bg-red-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-red-700 hover:shadow-lg
     focus:bg-red-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-red-800 active:shadow-lg transition duration-150 
     ease-in-out">
      Delete
   </button></td>
</tr>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp2\htdocs\Skill_Assessiment\resources\views/admin/add_stats.blade.php ENDPATH**/ ?>